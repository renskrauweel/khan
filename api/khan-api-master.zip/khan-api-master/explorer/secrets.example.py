
# The consumer key and secret for your app. To obtain these, visit:
# http://www.khanacademy.org/api-apps/register
consumer_key    = ""
consumer_secret = ""
    
# The base URL your app is talking to. You won't need to change this.
server_url = "http://www.khanacademy.org"
    
# The secret key used to encrypt your cookies. Generate this randomly by
# following the directions at:
# http://flask.pocoo.org/docs/quickstart/#sessions
app_secret_key = ''
